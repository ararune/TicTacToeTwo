import React, { Component } from 'react';
import './App.css';
import './index.css';
import Status from './components/Status';

/* Neuspjeli pokusaj da napravim reset funkciju
var mysample = 1;
function reset(varval)
{
  mysample= varval;
  if (mysample == 0) {
    return (
      this.state = {
      board : Array(9).fill(null),
      // player je null dok ne izabere X ili O
      player : null,
      winner: null
    }
      );
  }
  
}
*/
 /*var mysample = 1; */
class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      board : Array(9).fill(null),
      // player je null dok ne izabere X ili O
      player : null,
      winner: null,
      playerX: 0,
      playerO: 0,
      draw: 0
    }
  }
  vanillaState () {
    return {board: Array(9).fill(null),
            player: null,
            winner: null
          };
  }
  scoreboard () {
    return {board: Array(9).fill(null),
            player: null,
            winner: null
          };
  }
  reset () {  
    this.setState(this.vanillaState()) 
  }
  /*highlightWinningSquares(winningSquares, color) {
     for( var i = 0; i < winningSquares.length; i++ )
  {
    document.getElementById( winningSquares[i] ).style.backgroundColor = color;
  }
  }
  */
  checkWinner(){
    // winning lines za 3x3
    let winLines = [
    ["0","1","2"],
    ["3","4","5"],
    ["6","7","8"],
    ["0","3","6"],
    ["1","4","7"],
    ["2","5","8"],
    ["0","4","8"],
    ["2","4","6"],
    ]
    // funkcija provjere pobjednika
    this.checkMatch(winLines)
    } 
    /*  checkMatch(winLines) {

        for (let index = 0; index < winLines.length; index++) {
            const [a,b,c]= winLines[index];
            let board = this.state.board
          if (board[a] && board[a] 
            === board[b] && board[a] 
            === board[c])  {
              ;
    // Kad je uvjet ispunjen minjamo stanje winnera u X ili O
            this.setState({
              winner: this.state.player
            })
            }
          }

          
         }
*/
/*
 checkMatch (winLines) {
         let {player, board, winner, playerX, playerO} = this.state
         for(let index=0; index < winLines.length; index++){
             const [a,b,c] = winLines[index]
             if(board[a] && board[a] 
            === board[b] && board[a] 
            === board[c]){
                 (player === 'X') ? playerX ++ : playerO ++
                 this.setState({ winner: player, playerX: playerX, playerO: playerO})
             }
             
         }
         
     }
     */
     checkMatch = (winLines) => {
         let {player, board, playerX, playerO, draw} = this.state
         for(let i=0; i < winLines.length; i++){
             const [a,b,c] = winLines[i]
             if(board[a] && board[a] === board[b] && board[a] === board[c]){
                 (player === 'X') ? playerX += 1 : playerO += 1
                 this.setState({ winner: player, 
                  player: null, 
                  playerX: playerX, 
                  playerO: playerO,
                  draw: draw})
             }
         }
         if(!this.state.winner && this.state.board.indexOf(null) === -1 && player!= null){
             this.setState({
              winner: "Draw" ,
              draw : draw+=1
             })
         }
     }
  handleClick(index) {
    // Zaustavljamo mogucnost da se player promini prije nego se izabere player
    // i klikne start
  
    if(this.state.player && !this.state.winner) {
      let newBoard = this.state.board
    // S ovim uvjetom primamo vrijednost samo ako je polje prazno
    // i drugi uvjet nam služi da blokira unos ako imamo pobjednika
    if(this.state.board[index] === null && !this.state.winner){
      newBoard[index] = this.state.player
      // Minjaj playera samo ako klikne na prazno polje
      this.setState({
     board: newBoard,
     player: this.state.player === "X" ? "O" : "X"
    })
      //pozivamo funkciju provjere pobjednika
      this.checkWinner()

    }
    
    }

  }

  setPlayer(player) {
    this.setState({player})
  }
  renderBoxes() {
    return this.state.board.map(
      (box, index) => 
      <div className="box" key={index} 
      onClick={() =>this.handleClick(index)}>
      {box} </div>
      )
  }
  // U render stavljamo JavaScript
  render() { 

      
    // U return stavljamo JSX
      return (
        <div className="container">
          <h1>Tic Tac Toe</h1>
          <Status
          player={this.state.player}
          setPlayer={(e) => { this.setPlayer(e) }}
          winner={this.state.winner}
        />
          <div className="board">
            {this.renderBoxes()}
            </div>
            <button className="newReset"onClick= {() => this.reset()}>Clear Board</button>
            <div className='score'>
          <div className='row'>
            <div className='x-row'>
            O Wins: {this.state.playerO}  Draw: {this.state.draw}  X Wins: {this.state.playerX}
            </div>
            </div>
            </div>

        </div>
      );
  }
}

export default App;